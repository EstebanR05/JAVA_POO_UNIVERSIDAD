/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.esteban.exposicion;

/**
 *
 * @author e0507
 */
public abstract class Animal {

    public abstract void hacerSonido();
}
